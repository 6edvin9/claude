(() => {
  const modalSelector = '.agc-quote, .agc-support-modal, .agc-image-lightbox';
  let activeModal = null;
  let lastFocus = null;

  const focusables = (root) => Array.from(
    root.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')
  ).filter((el) => !el.hasAttribute('hidden') && el.getAttribute('aria-hidden') !== 'true');

  const setBodyLock = (locked) => {
    document.body.classList.toggle('agc-modal-lock', locked);
  };


  const quoteProfiles = {
    project: {
      kicker: 'Project Help',
      title: 'Get pricing or product guidance.',
      lede: 'Tell us which system you are interested in and our team will help you with product selection, project pricing, or the next step.',
      chips: ['Factory Direct', 'Custom Sizing', 'Showroom Support'],
      path: 'Project Pricing / Product Guidance',
      needLabel: 'What do you need?',
      needs: ['Project pricing', 'Product guidance', 'Showroom visit', 'Shipping question', 'General inquiry'],
      messageLabel: 'Project details',
      messagePlaceholder: 'Include measurements, quantities, city, finish preferences, or anything important about the project.',
      micro: 'For contractor or homeowner-specific support, choose the matching option from the Need Help menu.'
    },
    partner: {
      kicker: 'Contractor / Homeowner',
      title: 'Let’s point you to the right path.',
      lede: 'Whether you are sourcing for a job or shopping for your own property, send us the basics and we will guide you to the best next step.',
      chips: ['Contractor Pricing', 'Homeowner Guidance', 'Material Packages'],
      path: 'Contractor / Homeowner Support',
      needLabel: 'Best describes your need',
      needs: ['Product recommendation', 'Material package pricing', 'Custom sizes / design', 'Contractor pricing / partnership', 'Sample or showroom visit'],
      messageLabel: 'Project or purchase details',
      messagePlaceholder: 'Tell us about the property, measurements, quantities, timeline, or what you are trying to source.',
      micro: 'We can help with standard products, custom project support, and contractor-focused material pricing.'
    }
  };

  const configureQuoteModal = (mode = 'project') => {
    const modal = document.getElementById('agc-project-pricing-modal');
    if (!modal) return null;
    const profile = quoteProfiles[mode] || quoteProfiles.project;
    modal.dataset.agQuoteMode = mode;

    const setText = (selector, value) => {
      const node = modal.querySelector(selector);
      if (node) node.textContent = value;
    };
    setText('[data-ag-quote-kicker]', profile.kicker);
    setText('[data-ag-quote-title]', profile.title);
    setText('[data-ag-quote-lede]', profile.lede);
    setText('[data-ag-quote-need-label]', profile.needLabel);
    setText('[data-ag-quote-message-label]', profile.messageLabel);
    setText('[data-ag-quote-micro]', profile.micro);

    modal.querySelectorAll('[data-ag-quote-chip]').forEach((chip, index) => {
      chip.textContent = profile.chips[index] || '';
    });

    const path = modal.querySelector('[data-ag-quote-path]');
    if (path) path.value = profile.path;

    const need = modal.querySelector('[data-ag-quote-need]');
    if (need) {
      const previous = need.value;
      need.replaceChildren(...profile.needs.map((label) => {
        const option = document.createElement('option');
        option.textContent = label;
        option.value = label;
        return option;
      }));
      if (profile.needs.includes(previous)) need.value = previous;
    }

    const message = modal.querySelector('[data-ag-quote-message]');
    if (message) message.placeholder = profile.messagePlaceholder;
    return modal;
  };

  const openModal = (modal, trigger) => {
    if (!modal) return;
    const transitioning = Boolean(activeModal && activeModal !== modal);
    if (transitioning) closeModal(activeModal, false);
    if (!transitioning) lastFocus = trigger || document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    activeModal = modal;
    setBodyLock(true);
    const items = focusables(modal);
    if (items[0]) window.requestAnimationFrame(() => items[0].focus());
  };

  const closeModal = (modal, restoreFocus = true) => {
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    if (activeModal === modal) activeModal = null;
    if (!document.querySelector('.agc-quote.is-open, .agc-support-modal.is-open, .agc-image-lightbox.is-open')) setBodyLock(false);
    if (restoreFocus && lastFocus && typeof lastFocus.focus === 'function') {
      window.requestAnimationFrame(() => lastFocus.focus());
    }
  };

  const getLightbox = () => {
    let lightbox = document.getElementById('agc-image-lightbox');
    if (lightbox) return lightbox;
    lightbox = document.createElement('div');
    lightbox.id = 'agc-image-lightbox';
    lightbox.className = 'agc-home agc-image-lightbox';
    lightbox.setAttribute('aria-hidden', 'true');
    lightbox.setAttribute('role', 'dialog');
    lightbox.setAttribute('aria-modal', 'true');
    lightbox.setAttribute('aria-label', 'Image viewer');
    lightbox.innerHTML = `
      <div class="agc-image-lightbox__dialog" role="document">
        <button type="button" class="agc-image-lightbox__close" data-ag-lightbox-close aria-label="Close image viewer">×</button>
        <div class="agc-image-lightbox__stage">
          <img class="agc-image-lightbox__image" alt="" decoding="async">
        </div>
        <p class="agc-image-lightbox__caption"></p>
      </div>`;
    document.body.appendChild(lightbox);
    return lightbox;
  };

  const openLightbox = (trigger) => {
    const src = trigger.getAttribute('data-ag-src');
    if (!src) return;
    const lightbox = getLightbox();
    const image = lightbox.querySelector('.agc-image-lightbox__image');
    const caption = lightbox.querySelector('.agc-image-lightbox__caption');
    const text = trigger.getAttribute('data-ag-caption') || '';
    image.src = src;
    image.alt = text;
    caption.textContent = text;
    caption.hidden = !text;
    openModal(lightbox, trigger);
  };

  document.addEventListener('click', (event) => {
    const lightboxTrigger = event.target.closest('[data-ag-lightbox]');
    if (lightboxTrigger) {
      event.preventDefault();
      openLightbox(lightboxTrigger);
      return;
    }

    const genericTrigger = event.target.closest('[data-ag-open-modal]');
    if (genericTrigger) {
      event.preventDefault();
      const id = genericTrigger.getAttribute('data-ag-open-modal');
      if (id === 'agc-project-pricing-modal' || id === 'agc-partner-modal') {
        const mode = id === 'agc-partner-modal' ? 'partner' : (genericTrigger.dataset.agFormMode || 'project');
        openModal(configureQuoteModal(mode), genericTrigger);
      } else {
        openModal(document.getElementById(id), genericTrigger);
      }
      return;
    }

    const pricingTrigger = event.target.closest('[data-ag-project-pricing]');
    if (pricingTrigger) {
      event.preventDefault();
      openModal(configureQuoteModal('project'), pricingTrigger);
      return;
    }

    const supportTrigger = event.target.closest('[data-ag-support-open]');
    if (supportTrigger) {
      event.preventDefault();
      openModal(document.getElementById(supportTrigger.getAttribute('data-ag-support-open')), supportTrigger);
      return;
    }

    const closeTrigger = event.target.closest('[data-ag-close-modal], [data-agc-close], [data-ag-support-close], [data-ag-lightbox-close]');
    if (closeTrigger) {
      event.preventDefault();
      closeModal(closeTrigger.closest(modalSelector));
      return;
    }

    if (activeModal && event.target === activeModal) closeModal(activeModal);
  });

  document.addEventListener('keydown', (event) => {
    if (!activeModal) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closeModal(activeModal);
      return;
    }
    if (event.key === 'Tab') {
      const items = focusables(activeModal);
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });

  const statusModal = document.querySelector('.agc-quote .form-status, .agc-quote .form__message');
  if (statusModal) {
    const modal = statusModal.closest('.agc-quote');
    if (modal) openModal(configureQuoteModal(modal.dataset.agQuoteMode || 'project'), null);
  }
})();
