(function () {
  'use strict';

  var lightbox;
  var lightboxImage;
  var lightboxVideo;
  var lightboxCaption;

  function ensureLightbox() {
    if (lightbox) return;
    lightbox = document.createElement('div');
    lightbox.className = 'aglv-lightbox';
    lightbox.setAttribute('aria-hidden', 'true');
    lightbox.innerHTML = '<div class="aglv-lightbox__inner" role="dialog" aria-modal="true" aria-label="Media preview"><button type="button" class="aglv-lightbox__close" aria-label="Close media preview">×</button><img alt=""><video controls playsinline preload="metadata"></video><div class="aglv-lightbox__caption"></div></div>';
    document.body.appendChild(lightbox);
    lightboxImage = lightbox.querySelector('img');
    lightboxVideo = lightbox.querySelector('video');
    lightboxCaption = lightbox.querySelector('.aglv-lightbox__caption');
    lightbox.querySelector('.aglv-lightbox__close').addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', function (event) {
      if (event.target === lightbox) closeLightbox();
    });
  }

  function openLightbox(button) {
    ensureLightbox();
    var videoSrc = button.getAttribute('data-aglv-video');
    if (videoSrc) {
      lightboxImage.hidden = true;
      lightboxImage.removeAttribute('src');
      lightboxVideo.hidden = false;
      lightboxVideo.poster = button.getAttribute('data-aglv-poster') || '';
      lightboxVideo.src = videoSrc;
      lightboxVideo.load();
    } else {
      lightboxVideo.pause();
      lightboxVideo.removeAttribute('src');
      lightboxVideo.hidden = true;
      lightboxImage.hidden = false;
      lightboxImage.src = button.getAttribute('data-aglv-src') || '';
      lightboxImage.alt = button.getAttribute('data-aglv-alt') || '';
    }
    lightboxCaption.textContent = button.getAttribute('data-aglv-caption') || '';
    lightbox.classList.add('is-open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.classList.add('aglv-lightbox-open');
    lightbox.querySelector('.aglv-lightbox__close').focus();
  }

  function closeLightbox() {
    if (!lightbox) return;
    if (lightboxVideo) {
      lightboxVideo.pause();
      lightboxVideo.removeAttribute('src');
      lightboxVideo.load();
    }
    lightbox.classList.remove('is-open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('aglv-lightbox-open');
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-aglv-lightbox]');
    if (button) openLightbox(button);
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') closeLightbox();
  });
})();
