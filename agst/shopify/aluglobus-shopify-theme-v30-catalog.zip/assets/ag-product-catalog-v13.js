(() => {
  const prepareStory = (story) => {
    if (!story || story.dataset.agEnhanced === 'true') return;
    story.dataset.agEnhanced = 'true';

    const premium = story.querySelector('.agc-premium-content--normalized');
    if (premium) {
      premium.querySelectorAll(':scope > style').forEach((style) => style.remove());
      [...premium.children].forEach((block, index) => {
        if (block.tagName !== 'SECTION') return;
        block.classList.add('agc-premium-block', `agc-premium-block--${index + 1}`);
        [...block.childNodes].forEach((node) => {
          if (node.nodeType !== Node.TEXT_NODE) return;
          if (!node.textContent.trim()) { node.remove(); return; }
          const text = document.createElement('span');
          text.className = 'agc-premium-text';
          text.textContent = node.textContent.trim();
          node.replaceWith(text);
        });
        if (index === 1) {
          const children = [...block.children];
          for (let i = 0; i < children.length; i += 2) {
            const item = document.createElement('div');
            item.className = 'agc-premium-trust-item';
            block.insertBefore(item, children[i]);
            item.append(children[i]);
            if (children[i + 1]) item.append(children[i + 1]);
          }
        }
      });
    }

    story.querySelectorAll('.agc-description h1').forEach((heading) => {
      const replacement = document.createElement('h2');
      Array.from(heading.attributes).forEach((attribute) => replacement.setAttribute(attribute.name, attribute.value));
      replacement.innerHTML = heading.innerHTML;
      heading.replaceWith(replacement);
    });

    story.querySelectorAll('img').forEach((image) => {
      if (!image.hasAttribute('loading')) image.loading = 'lazy';
      if (!image.hasAttribute('decoding')) image.decoding = 'async';
      if (!image.alt.trim()) image.alt = document.querySelector('h1')?.textContent?.trim() || 'Aluglobus aluminum product';
    });

    story.querySelectorAll('.agc-description table').forEach((table) => {
      if (table.parentElement?.classList.contains('agc-table-scroll')) return;
      const wrapper = document.createElement('div');
      wrapper.className = 'agc-table-scroll';
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    });

    story.querySelectorAll('details').forEach((detail) => {
      const summary = detail.querySelector(':scope > summary');
      if (!summary) return;
      summary.setAttribute('aria-expanded', detail.open ? 'true' : 'false');
      detail.addEventListener('toggle', () => summary.setAttribute('aria-expanded', detail.open ? 'true' : 'false'));
    });
  };

  const prepareAll = (root = document) => root.querySelectorAll('[data-ag-catalog="v13"]').forEach(prepareStory);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => prepareAll());
  else prepareAll();
  document.addEventListener('shopify:section:load', (event) => prepareAll(event.target));
})();
