(() => {
  const links = document.querySelectorAll('[data-agp-lightbox]');
  if (!links.length) return;

  const overlay = document.createElement('div');
  overlay.className = 'agp-lightbox';
  overlay.setAttribute('aria-hidden', 'true');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.innerHTML = '<button class="agp-lightbox__close" type="button" aria-label="Close image">×</button><img class="agp-lightbox__image" alt="">';
  document.body.appendChild(overlay);

  const image = overlay.querySelector('.agp-lightbox__image');
  const closeButton = overlay.querySelector('.agp-lightbox__close');
  let lastFocus = null;

  const close = () => {
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    image.removeAttribute('src');
    document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  };

  links.forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      lastFocus = link;
      image.src = link.href;
      const img = link.querySelector('img');
      image.alt = img ? img.alt : '';
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      closeButton.focus();
    });
  });

  closeButton.addEventListener('click', close);
  overlay.addEventListener('click', (event) => { if (event.target === overlay) close(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && overlay.classList.contains('is-open')) close(); });
})();
