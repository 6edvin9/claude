(() => {
  const scheduleIdle = (callback, timeout = 1200) => {
    if ('requestIdleCallback' in window) window.requestIdleCallback(callback, { timeout });
    else window.setTimeout(callback, 80);
  };

  const prepareCatalog = (root = document) => {
    const productTitle = document.querySelector('.product__title h1')?.textContent?.trim() || 'Aluglobus aluminum product';

    root.querySelectorAll('[data-ag-catalog="v14"]').forEach((section) => {
      if (section.dataset.agV14Ready) return;
      section.dataset.agV14Ready = 'true';

      section.querySelectorAll('.agv14-detail-content--imported').forEach((content) => {
        content.querySelectorAll('style, link[rel="stylesheet"]').forEach((node) => node.remove());
        content.querySelectorAll('[style]').forEach((node) => node.removeAttribute('style'));
      });

      section.querySelectorAll('details').forEach((detail) => {
        const summary = detail.querySelector(':scope > summary');
        if (!summary) return;
        const sync = () => summary.setAttribute('aria-expanded', detail.open ? 'true' : 'false');
        sync();
        detail.addEventListener('toggle', sync, { passive: true });
      });

      section.querySelectorAll('img').forEach((image) => {
        if (!image.alt.trim()) image.alt = productTitle;
        if (!image.hasAttribute('loading')) image.loading = 'lazy';
        image.decoding = 'async';
      });
    });
  };

  const initStickyBars = (root = document) => {
    root.querySelectorAll('[data-ag-v14-sticky]').forEach((bar) => {
      if (bar.dataset.agV14Ready) return;
      bar.dataset.agV14Ready = 'true';
      const main = document.getElementById(bar.dataset.mainProduct);
      const options = bar.querySelector('[data-ag-v14-options]');
      const price = bar.querySelector('[data-ag-v14-sticky-price]');
      const info = main?.querySelector('[id^="ProductInfo-"]');
      const livePrice = main?.querySelector('[id^="price-"]');
      const updatePrice = () => {
        const value = livePrice?.querySelector('.price-item--sale, .price-item--regular')?.textContent?.trim();
        if (value && price) price.textContent = value;
      };

      updatePrice();
      if (livePrice) new MutationObserver(updatePrice).observe(livePrice, { subtree: true, childList: true, characterData: true });

      options?.addEventListener('click', () => {
        info?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        window.setTimeout(() => info?.querySelector('input:not([type="hidden"]), select, button')?.focus({ preventScroll: true }), 500);
      });

      if (main && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver(([entry]) => {
          const show = !entry.isIntersecting && entry.boundingClientRect.top < 0;
          bar.classList.toggle('is-visible', show);
          bar.setAttribute('aria-hidden', show ? 'false' : 'true');
        }, { threshold: 0.04 });
        observer.observe(main);
      }
    });
  };

  const init = (root = document) => {
    /* Sticky purchase/navigation UI is lightweight and useful immediately. The
       larger imported-description cleanup can wait for an idle period so it does
       not compete with the first tap/click, which directly targets INP. */
    initStickyBars(root);
    scheduleIdle(() => prepareCatalog(root));
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init(), { once: true });
  } else {
    init();
  }

  document.addEventListener('shopify:section:load', (event) => init(event.target));
})();
