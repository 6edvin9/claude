(function(){
  'use strict';
  const WHATSAPP_NUMBER = '17473528824';

  function isExcluded(form){
    const text = ((form.action||'')+' '+(form.id||'')+' '+(form.className||'')).toLowerCase();
    return text.includes('search') || text.includes('cart') || text.includes('facet') || text.includes('predictive');
  }

  function getMessage(form){
    const data = new FormData(form);
    const lines = ['New Website Inquiry - Aluglobus'];
    const seen = Object.create(null);
    data.forEach((value,key)=>{
      if(value instanceof File){
        if(value.name) lines.push(key+': '+value.name);
      } else if(String(value).trim() && !seen[key]) {
        const cleanKey = key.replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
        lines.push(cleanKey+': '+value);
        seen[key]=true;
      }
    });
    lines.push('Page: '+window.location.href);
    return lines.join('\n');
  }

  /* One delegated submit handler replaces a subtree MutationObserver + repeated
     querySelectorAll('form') scans. It also works for forms inserted later. */
  document.addEventListener('submit', function(event){
    const form = event.target;
    if(!(form instanceof HTMLFormElement) || isExcluded(form)) return;
    event.preventDefault();
    if(typeof window.gtag === 'function'){
      window.gtag('event','conversion',{ send_to:'AW-18422563490/PCA5CIat-uwcEKKFyNBE' });
    }
    const url='https://wa.me/'+WHATSAPP_NUMBER+'?text='+encodeURIComponent(getMessage(form));
    window.open(url,'_blank','noopener');
  }, true);
})();
