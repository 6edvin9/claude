(function () {
  'use strict';

  var lastQuoteTrigger = null;

  function qsa(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function quoteModal() {
    return document.getElementById('ag-quote-modal');
  }

  function focusableQuoteElements(modal) {
    return qsa(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
      modal
    ).filter(function (element) {
      return element.getAttribute('aria-hidden') !== 'true';
    });
  }

  function openQuote(event) {
    if (event) event.preventDefault();
    var modal = quoteModal();
    if (!modal) return;

    lastQuoteTrigger = event && event.currentTarget ? event.currentTarget : document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('ag-quote-lock');

    var first = focusableQuoteElements(modal)[0];
    if (first) setTimeout(function () { first.focus(); }, 30);
  }

  function closeQuote() {
    var modal = quoteModal();
    if (!modal || modal.getAttribute('aria-hidden') === 'true') return;

    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('ag-quote-lock');

    if (lastQuoteTrigger && typeof lastQuoteTrigger.focus === 'function') {
      lastQuoteTrigger.focus({ preventScroll: true });
    }
  }

  qsa('[data-ag-quote-open], a[href="#ag-quote-modal"]').forEach(function (element) {
    element.addEventListener('click', openQuote);
  });
  qsa('[data-ag-quote-close]').forEach(function (element) {
    element.addEventListener('click', closeQuote);
  });

  var modal = quoteModal();
  if (modal) {
    modal.addEventListener('click', function (event) {
      if (event.target === modal) closeQuote();
    });
    modal.addEventListener('keydown', function (event) {
      if (event.key !== 'Tab') return;
      var focusable = focusableQuoteElements(modal);
      if (!focusable.length) return;
      var first = focusable[0];
      var last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    var submissionMessage = modal.querySelector('[role="status"], [role="alert"]');
    if (submissionMessage) {
      openQuote();
      setTimeout(function () { submissionMessage.focus(); }, 40);
    }
  }

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') closeQuote();
  });
})();

/* Elementor V2 section 1 / a2f6f8c */
(function () {
  'use strict';

  /*
   * =========================================================
   * ULTRA-LAZY VIDEO LIBRARY
   * =========================================================
   *
   * PERFORMANCE RULES:
   *
   * - No video element on initial load.
   * - No MP4 request on initial load.
   * - No thumbnails downloaded.
   * - No metadata requests.
   * - Dialog DOM created only after click.
   * - Only selected video receives an src.
   */

  var trigger =
    document.getElementById('aghVideoButton');

  if (!trigger) return;


  var videos = [
    {
      name: 'Aluglobus Main',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/01/shark-video.mp4'
    },
    {
      name: 'Zone Zero Products',
      src: 'https://globusgates.com/wp-content/uploads/2026/04/ZONE-ZERO-2.mp4'
    },
    {
      name: 'Aluminium Extrusion Line',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/YOUTUBE-ALU.mp4'
    },
    {
      name: 'Powder Coating',
      src: 'https://globusgates.com/wp-content/uploads/2026/04/7-Stage-1.mp4'
    },
    {
      name: 'Shop Assembly',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/3D-DESIGN.mp4'
    },
    {
      name: 'Fences',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/Youtube-Alu-1.mp4'
    },
    {
      name: 'Gates',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/YOUTUBE-VIDEO-ALU.mp4'
    },
    {
      name: 'Patio Covers',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/YOUTUBE-ALU-2.mp4'
    },
    {
      name: 'Wall Cladding',
      src: 'https://aluglobusfence.com/wp-content/uploads/2026/04/Youtube-Alu-3.mp4'
    }
  ];


  var dialog = null;
  var content = null;
  var lastFocus = null;


  function stopCurrentVideo() {

    if (!dialog) return;

    var video =
      dialog.querySelector('video');

    if (!video) return;

    video.pause();
    video.removeAttribute('src');
    video.load();
  }


  function closeDialog() {

    if (!dialog) return;

    stopCurrentVideo();

    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute('open');

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      lastFocus.focus({
        preventScroll: true
      });

    }

  }


  function renderList() {

    stopCurrentVideo();


    var html =
      '<div class="agh-dialog-head">' +

        '<h2 class="agh-dialog-title">' +
          'Explore Aluglobus Videos' +
        '</h2>' +

        '<button ' +
          'class="agh-dialog-close" ' +
          'type="button" ' +
          'data-agh-close>' +
          'Close' +
        '</button>' +

      '</div>' +

      '<div class="agh-dialog-list">';


    videos.forEach(
      function (video, index) {

        var number =
          String(index + 1)
            .padStart(2, '0');


        html +=
          '<button ' +
            'class="agh-dialog-video" ' +
            'type="button" ' +
            'data-agh-video="' +
            index +
          '">' +

            '<span class="agh-dialog-video-number">' +
              number +
            '</span>' +

            '<span class="agh-dialog-video-name">' +
              video.name +
            '</span>' +

          '</button>';

      }
    );


    html += '</div>';

    content.innerHTML = html;
  }


  function playVideo(index) {

    var item =
      videos[index];

    if (!item) return;


    content.innerHTML =
      '<div class="agh-dialog-head">' +

        '<button ' +
          'class="agh-dialog-back" ' +
          'type="button" ' +
          'data-agh-back>' +
          '← Back to Videos' +
        '</button>' +

        '<button ' +
          'class="agh-dialog-close" ' +
          'type="button" ' +
          'data-agh-close>' +
          'Close' +
        '</button>' +

      '</div>' +

      '<div class="agh-dialog-player">' +

        '<video ' +
          'controls ' +
          'playsinline ' +
          'preload="metadata" ' +
          'src="' +
          item.src +
        '">' +
        '</video>' +

      '</div>';


    var player =
      content.querySelector('video');


    if (player) {

      var promise =
        player.play();


      if (
        promise &&
        typeof promise.catch ===
        'function'
      ) {

        promise.catch(
          function () {}
        );

      }

    }

  }


  function ensureDialog() {

    if (dialog) return;


    dialog =
      document.createElement('dialog');


    dialog.className =
      'agh-dialog';


    dialog.setAttribute(
      'aria-label',
      'Aluglobus video library'
    );


    dialog.innerHTML =
      '<div class="agh-dialog-shell">' +
        '<div data-agh-content></div>' +
      '</div>';


    document.body.appendChild(
      dialog
    );


    content =
      dialog.querySelector(
        '[data-agh-content]'
      );


    /*
     * One delegated event listener handles the
     * complete modal.
     */

    dialog.addEventListener(
      'click',
      function (event) {

        var close =
          event.target.closest(
            '[data-agh-close]'
          );


        if (close) {

          closeDialog();

          return;

        }


        var back =
          event.target.closest(
            '[data-agh-back]'
          );


        if (back) {

          renderList();

          return;

        }


        var videoButton =
          event.target.closest(
            '[data-agh-video]'
          );


        if (videoButton) {

          playVideo(
            Number(
              videoButton.getAttribute(
                'data-agh-video'
              )
            )
          );

          return;

        }


        if (
          event.target ===
          dialog
        ) {

          closeDialog();

        }

      }
    );


    dialog.addEventListener(
      'close',
      stopCurrentVideo
    );

  }


  trigger.addEventListener(
    'click',
    function () {

      lastFocus =
        document.activeElement;


      ensureDialog();

      renderList();


      if (
        typeof dialog.showModal ===
        'function'
      ) {

        dialog.showModal();

      } else {

        dialog.setAttribute(
          'open',
          ''
        );

      }

    }
  );

})();


/* Elementor V2 section 5 / 27ebb2f */
(function () {
  'use strict';

  /*
   * FEATURED TESTIMONIAL VIDEO
   *
   * No <video> element exists during initial page load.
   * The MP4 request begins ONLY after the visitor clicks.
   */

  var button =
    document.getElementById(
      'agrPlayDaymond'
    );


  if (!button) return;


  button.addEventListener(
    'click',
    function () {

      var media =
        button.closest(
          '.agr-feature-media'
        );


      if (!media) return;


      /*
       * Prevent duplicate players.
       */

      if (
        media.querySelector(
          '.agr-video-loaded'
        )
      ) {
        return;
      }


      var video =
        document.createElement(
          'video'
        );


      video.className =
        'agr-video-loaded';


      video.src =
        'https://aluglobusfence.com/wp-content/uploads/2025/11/IG-SHARK-6.mp4';


      video.controls = true;
      video.playsInline = true;

      /*
       * The click itself is the request trigger,
       * so metadata loading is fine here.
       */

      video.preload =
        'metadata';


      media.appendChild(
        video
      );


      var promise =
        video.play();


      if (
        promise &&
        typeof promise.catch ===
        'function'
      ) {

        promise.catch(
          function () {}
        );

      }

    },
    {
      once: true
    }
  );

})();


/* Elementor V2 section 6 / 484370c */
(function () {

  'use strict';


  /*
   * =========================================================
   * ORIGINAL VIDEO HYDRATION BEHAVIOR PRESERVED
   * =========================================================
   *
   * - preload="none"
   * - does not hydrate on Save Data
   * - does not hydrate on slow 2G
   * - disabled for reduced motion
   * - disabled below 700px
   * - desktop video loads only near viewport
   */


  var video =
    document.getElementById(
      'pcs-hero-video'
    );


  if (!video) {
    return;
  }


  var connection =
    navigator.connection ||
    navigator.mozConnection ||
    navigator.webkitConnection;


  var conserve =
    !!(
      connection &&
      (
        connection.saveData ||
        /(^|-)2g$/.test(
          connection.effectiveType || ''
        )
      )
    );


  var reduced =
    !!(
      window.matchMedia &&
      window.matchMedia(
        '(prefers-reduced-motion: reduce)'
      ).matches
    );


  if (
    conserve ||
    reduced ||
    window.innerWidth < 700
  ) {

    return;

  }



  function hydrate() {

    if (
      video.dataset.hydrated ===
      '1'
    ) {

      return;

    }


    video.src =
      video.getAttribute(
        'data-src'
      );


    video.dataset.hydrated =
      '1';


    video.load();

  }



  function play() {

    hydrate();


    var promise =
      video.play();


    if (
      promise &&
      typeof promise.catch ===
      'function'
    ) {

      promise.catch(
        function () {}
      );

    }

  }



  if (
    'IntersectionObserver' in window
  ) {


    var observer =
      new IntersectionObserver(

        function (entries) {


          entries.forEach(
            function (entry) {


              if (
                entry.isIntersecting
              ) {

                play();

              } else if (
                video.dataset.hydrated ===
                '1'
              ) {

                video.pause();

              }

            }
          );

        },

        {
          rootMargin:
            '450px 0px'
        }

      );


    observer.observe(
      video
    );


  } else {


    window.addEventListener(
      'load',
      play,
      {
        once: true
      }
    );


  }

})();


/* Elementor V2 section 9 / 885b9ee */
(function () {
  'use strict';


  /*
   * =========================================================
   * LIGHTWEIGHT IMAGE LIGHTBOX
   * =========================================================
   *
   * - No modal DOM initially
   * - No duplicate hidden image
   * - Created only after user interaction
   * - Reuses original image URL
   * - No external library
   */


  var section =
    document.querySelector(
      '.agfd'
    );


  if (!section) {
    return;
  }



  var trigger =
    section.querySelector(
      '[data-agfd-lightbox]'
    );


  if (!trigger) {
    return;
  }



  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agfd-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Expanded aluminum patio cover image'
    );


    dialog.innerHTML =

      '<div class="agfd-lightbox-shell">' +

        '<button ' +
          'class="agfd-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close enlarged image">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<img ' +
          'class="agfd-lightbox-image" ' +
          'alt=""' +
        '>' +


        '<p class="agfd-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agfd-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agfd-lightbox-caption'
      );


    var close =
      dialog.querySelector(
        '.agfd-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agfd-lightbox-shell'
      );


    close.addEventListener(
      'click',
      closeLightbox
    );


    dialog.addEventListener(
      'click',
      function (event) {

        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );


    dialog.addEventListener(
      'close',
      cleanup
    );

  }



  function openLightbox() {

    createLightbox();


    lastFocus =
      document.activeElement;


    modalImage.src =
      trigger.getAttribute(
        'data-src'
      );


    modalImage.alt =
      trigger.getAttribute(
        'data-alt'
      ) || '';


    modalCaption.textContent =
      trigger.getAttribute(
        'data-caption'
      ) || '';


    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );

      cleanup();

    }

  }



  function cleanup() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  trigger.addEventListener(
    'click',
    openLightbox
  );

})();


/* Elementor V2 section 10 / b836379 */
(function () {
  'use strict';


  /*
   * =========================================================
   * LIGHTWEIGHT IMAGE LIGHTBOX
   * =========================================================
   *
   * PERFORMANCE:
   *
   * - No dialog in initial DOM
   * - No duplicate hidden image
   * - No external library
   * - Created only after user clicks the image
   */


  var section =
    document.querySelector(
      '.agpartner'
    );


  if (!section) {
    return;
  }


  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agpartner-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Expanded Aluglobus partner program image'
    );


    dialog.innerHTML =

      '<div class="agpartner-lightbox-shell">' +

        '<button ' +
          'class="agpartner-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close enlarged image">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<img ' +
          'class="agpartner-lightbox-image" ' +
          'alt=""' +
        '>' +


        '<p class="agpartner-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agpartner-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agpartner-lightbox-caption'
      );


    var close =
      dialog.querySelector(
        '.agpartner-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agpartner-lightbox-shell'
      );


    close.addEventListener(
      'click',
      closeLightbox
    );


    dialog.addEventListener(
      'click',
      function (event) {

        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );


    dialog.addEventListener(
      'close',
      cleanup
    );

  }



  function openLightbox(trigger) {

    if (!trigger) {
      return;
    }


    var src =
      trigger.getAttribute(
        'data-src'
      );


    if (!src) {
      return;
    }


    createLightbox();


    lastFocus =
      document.activeElement;


    modalImage.src =
      src;


    modalImage.alt =
      trigger.getAttribute(
        'data-alt'
      ) || '';


    modalCaption.textContent =
      trigger.getAttribute(
        'data-caption'
      ) || '';


    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );

      cleanup();

    }

  }



  function cleanup() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  section.addEventListener(
    'click',
    function (event) {


      var trigger =
        event.target.closest(
          '[data-agpartner-lightbox]'
        );


      if (!trigger) {
        return;
      }


      event.preventDefault();


      openLightbox(
        trigger
      );

    }
  );

})();


/* Elementor V2 section 12 / dc2a527 */
(function () {
  'use strict';


  /*
   * =========================================================
   * ALUGLOBUS FACTORY / PATIO IMAGE LIGHTBOX
   * =========================================================
   *
   * PERFORMANCE:
   *
   * - No dialog exists on initial load
   * - No duplicate hidden images
   * - Dialog created only after first image click
   * - Reuses original image URL
   * - One delegated click listener handles both images
   * - No external lightbox library
   */


  var section =
    document.querySelector(
      '.agfp'
    );


  if (!section) {
    return;
  }



  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  /* =======================================================
     CREATE
     ======================================================= */

  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agfp-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Expanded Aluglobus patio or manufacturing image'
    );


    dialog.innerHTML =

      '<div class="agfp-lightbox-shell">' +

        '<button ' +
          'class="agfp-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close enlarged image">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<img ' +
          'class="agfp-lightbox-image" ' +
          'alt=""' +
        '>' +


        '<p class="agfp-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agfp-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agfp-lightbox-caption'
      );


    var close =
      dialog.querySelector(
        '.agfp-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agfp-lightbox-shell'
      );


    close.addEventListener(
      'click',
      closeLightbox
    );


    dialog.addEventListener(
      'click',
      function (event) {


        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );


    dialog.addEventListener(
      'close',
      cleanup
    );

  }



  /* =======================================================
     OPEN
     ======================================================= */

  function openLightbox(trigger) {

    if (!trigger) {
      return;
    }


    var src =
      trigger.getAttribute(
        'data-src'
      );


    if (!src) {
      return;
    }


    createLightbox();


    lastFocus =
      document.activeElement;


    modalImage.src =
      src;


    modalImage.alt =
      trigger.getAttribute(
        'data-alt'
      ) || '';


    modalCaption.textContent =
      trigger.getAttribute(
        'data-caption'
      ) || '';


    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  /* =======================================================
     CLOSE
     ======================================================= */

  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );

      cleanup();

    }

  }



  /* =======================================================
     CLEANUP
     ======================================================= */

  function cleanup() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  /* =======================================================
     ONE CLICK LISTENER FOR BOTH IMAGES
     ======================================================= */

  section.addEventListener(
    'click',
    function (event) {


      var trigger =
        event.target.closest(
          '[data-agfp-lightbox]'
        );


      if (!trigger) {
        return;
      }


      event.preventDefault();


      openLightbox(
        trigger
      );

    }
  );

})();


/* Elementor V2 section 13 / 1eaf2a1 */
(function () {
  'use strict';

  /*
   * =========================================================
   * ALUGLOBUS YOUTUBE CONTROLLER
   * =========================================================
   *
   * PERFORMANCE:
   *
   * - There are NO iframes in the initial HTML.
   * - YouTube JS/player resources do not load initially.
   * - YouTube thumbnails are not requested.
   * - Only the video the visitor clicks is loaded.
   * - If another video is opened, the previous player
   *   is destroyed completely.
   * - One delegated click listener handles all 3 videos.
   */

  var grid =
    document.getElementById(
      'agxGrid'
    );


  if (!grid) return;


  var activeCard = null;


  function resetActiveVideo() {

    if (!activeCard) return;


    var frame =
      activeCard.querySelector(
        '.agx-youtube-frame'
      );


    if (frame) {
      frame.remove();
    }


    activeCard.classList.remove(
      'agx-is-playing'
    );


    activeCard = null;

  }



  function playVideo(card) {

    if (!card) return;


    var videoId =
      card.getAttribute(
        'data-agx-youtube'
      );


    if (!videoId) return;


    /*
     * Clicking the already-active video card does nothing.
     */

    if (
      activeCard === card &&
      card.querySelector(
        '.agx-youtube-frame'
      )
    ) {

      return;

    }


    /*
     * Destroy any previously active player.
     */

    resetActiveVideo();


    var media =
      card.querySelector(
        '.agx-media'
      );


    if (!media) return;


    var iframe =
      document.createElement(
        'iframe'
      );


    iframe.className =
      'agx-youtube-frame';


    /*
     * Privacy-enhanced YouTube.
     */

    iframe.src =
      'https://www.youtube-nocookie.com/embed/' +
      encodeURIComponent(videoId) +
      '?autoplay=1' +
      '&playsinline=1' +
      '&rel=0' +
      '&modestbranding=1';


    iframe.title =
      'Aluglobus video player';


    iframe.allow =
      'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';


    iframe.allowFullscreen =
      true;


    media.appendChild(
      iframe
    );


    card.classList.add(
      'agx-is-playing'
    );


    activeCard =
      card;

  }



  /*
   * Single delegated event.
   */

  grid.addEventListener(
    'click',
    function (event) {

      var trigger =
        event.target.closest(
          '.agx-video-trigger'
        );


      if (!trigger) return;


      var card =
        trigger.closest(
          '[data-agx-youtube]'
        );


      playVideo(
        card
      );

    }
  );

})();


/* Elementor V2 section 14 / 33ef0cd */
(function () {
  'use strict';


  /*
   * =========================================================
   * ALUGLOBUS IMAGE LIGHTBOX
   * =========================================================
   *
   * PERFORMANCE:
   *
   * 1. Modal does not exist on initial page load.
   * 2. No duplicate images are downloaded.
   * 3. Modal is created only after first interaction.
   * 4. Same source URL is used for enlarged image.
   * 5. One delegated listener handles all four images.
   * 6. No external lightbox library.
   */


  var section =
    document.querySelector(
      '.agc'
    );


  if (!section) {
    return;
  }


  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  /* =======================================================
     CREATE LIGHTBOX
     ======================================================= */

  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agc-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Aluglobus image preview'
    );


    dialog.innerHTML =
      '<div class="agc-lightbox-shell">' +

        '<button ' +
          'class="agc-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close image preview">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<div class="agc-lightbox-image-wrap">' +

          '<img ' +
            'class="agc-lightbox-image" ' +
            'alt=""' +
          '>' +

        '</div>' +


        '<p class="agc-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agc-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agc-lightbox-caption'
      );


    var closeButton =
      dialog.querySelector(
        '.agc-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agc-lightbox-shell'
      );



    /* Close button */

    closeButton.addEventListener(
      'click',
      closeLightbox
    );



    /*
     * Clicking the dark empty area closes the lightbox.
     * Clicking the image itself does not.
     */

    dialog.addEventListener(
      'click',
      function (event) {

        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );



    /*
     * Native dialog "cancel" covers Escape key.
     */

    dialog.addEventListener(
      'cancel',
      function () {

        cleanupLightbox();

      }
    );



    dialog.addEventListener(
      'close',
      cleanupLightbox
    );

  }



  /* =======================================================
     OPEN
     ======================================================= */

  function openLightbox(trigger) {

    if (!trigger) {
      return;
    }


    var source =
      trigger.getAttribute(
        'data-agc-src'
      );


    if (!source) {
      return;
    }


    var caption =
      trigger.getAttribute(
        'data-agc-caption'
      ) ||
      'Aluglobus image';


    createLightbox();


    lastFocus =
      document.activeElement;


    /*
     * The enlarged image is attached only now.
     */

    modalImage.src =
      source;


    modalImage.alt =
      caption;


    modalCaption.textContent =
      caption;



    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      /*
       * Fallback for older browsers.
       */

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  /* =======================================================
     CLOSE
     ======================================================= */

  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );


      cleanupLightbox();

    }

  }



  /* =======================================================
     CLEANUP
     ======================================================= */

  function cleanupLightbox() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  /* =======================================================
     ONE CLICK HANDLER FOR ALL IMAGES
     ======================================================= */

  section.addEventListener(
    'click',
    function (event) {

      var trigger =
        event.target.closest(
          '[data-agc-lightbox]'
        );


      if (!trigger) {
        return;
      }


      event.preventDefault();


      openLightbox(
        trigger
      );

    }
  );

})();


/* Elementor V2 section 15 / 41d7bdc */
(function () {
  'use strict';


  /*
   * =========================================================
   * CLICK-TO-LOAD YOUTUBE
   * =========================================================
   *
   * INITIAL LOAD:
   *
   * - NO iframe
   * - NO youtube.com request
   * - NO YouTube JS
   * - NO video metadata
   *
   * Player is created ONLY after user click.
   */


  var video =
    document.getElementById(
      'agpVideo'
    );


  if (!video) {
    return;
  }


  var trigger =
    video.querySelector(
      '.agp-play-button'
    );


  if (!trigger) {
    return;
  }



  trigger.addEventListener(
    'click',
    function () {


      /*
       * Prevent duplicate iframe.
       */

      if (
        video.querySelector(
          '.agp-youtube'
        )
      ) {

        return;

      }



      var id =
        video.getAttribute(
          'data-youtube-id'
        );


      if (!id) {
        return;
      }



      var iframe =
        document.createElement(
          'iframe'
        );


      iframe.className =
        'agp-youtube';


      iframe.src =
        'https://www.youtube-nocookie.com/embed/' +
        encodeURIComponent(id) +
        '?autoplay=1' +
        '&playsinline=1' +
        '&rel=0' +
        '&modestbranding=1';


      iframe.title =
        'ALU40 Universal DIY Gate Installation Video';


      iframe.allow =
        'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';


      iframe.allowFullscreen =
        true;


      video.appendChild(
        iframe
      );

    },
    {
      once: true
    }
  );

})();


/* Elementor V2 section 16 / 93cd949 */
(function () {
  'use strict';


  /*
   * =========================================================
   * ULTRA-LIGHT IMAGE LIGHTBOX
   * =========================================================
   *
   * Performance:
   *
   * - No modal in initial HTML.
   * - No duplicate hidden image.
   * - Created only after user clicks the project image.
   * - Reuses the existing image URL.
   * - No external library.
   */


  var section =
    document.querySelector(
      '.agps'
    );


  if (!section) {
    return;
  }



  var trigger =
    section.querySelector(
      '[data-agps-lightbox]'
    );


  if (!trigger) {
    return;
  }



  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  /* =======================================================
     CREATE
     ======================================================= */

  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agps-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Expanded patio project image'
    );


    dialog.innerHTML =

      '<div class="agps-lightbox-shell">' +

        '<button ' +
          'class="agps-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close enlarged image">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<img ' +
          'class="agps-lightbox-image" ' +
          'alt=""' +
        '>' +


        '<p class="agps-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agps-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agps-lightbox-caption'
      );


    var close =
      dialog.querySelector(
        '.agps-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agps-lightbox-shell'
      );



    close.addEventListener(
      'click',
      closeLightbox
    );



    dialog.addEventListener(
      'click',
      function (event) {

        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );



    dialog.addEventListener(
      'close',
      cleanup
    );

  }



  /* =======================================================
     OPEN
     ======================================================= */

  function openLightbox() {

    createLightbox();


    lastFocus =
      document.activeElement;


    modalImage.src =
      trigger.getAttribute(
        'data-src'
      );


    modalImage.alt =
      trigger.getAttribute(
        'data-alt'
      ) || '';


    modalCaption.textContent =
      trigger.getAttribute(
        'data-caption'
      ) || '';


    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  /* =======================================================
     CLOSE
     ======================================================= */

  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );

      cleanup();

    }

  }



  /* =======================================================
     CLEANUP
     ======================================================= */

  function cleanup() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  trigger.addEventListener(
    'click',
    openLightbox
  );

})();


/* Elementor V2 section 17 / 0796344 */
(function () {
  'use strict';


  /*
   * =========================================================
   * ZONE ZERO VIDEO CONTROLLER
   * =========================================================
   *
   * PERFORMANCE:
   *
   * - ZERO YouTube iframe on initial load
   * - ZERO YouTube thumbnail request
   * - Local image acts as poster
   * - Only clicked video is loaded
   * - Only one iframe can exist at a time
   * - Previous iframe is removed entirely
   * - One delegated click listener for all eight cards
   */


  var grid =
    document.getElementById(
      'agzzGrid'
    );


  if (!grid) {
    return;
  }


  var activeCard = null;



  /* =======================================================
     RESET PLAYER
     ======================================================= */

  function resetPlayer() {

    if (!activeCard) {
      return;
    }


    var iframe =
      activeCard.querySelector(
        '.agzz-youtube'
      );


    if (iframe) {
      iframe.remove();
    }


    activeCard = null;

  }



  /* =======================================================
     PLAY
     ======================================================= */

  function playVideo(card) {

    if (!card) {
      return;
    }


    var videoId =
      card.getAttribute(
        'data-agzz-youtube'
      );


    if (!videoId) {
      return;
    }



    /*
     * If this card already has an active player,
     * do nothing.
     */

    if (
      activeCard === card &&
      card.querySelector(
        '.agzz-youtube'
      )
    ) {

      return;

    }



    /*
     * Remove previous player.
     */

    resetPlayer();



    var media =
      card.querySelector(
        '.agzz-media'
      );


    if (!media) {
      return;
    }



    var iframe =
      document.createElement(
        'iframe'
      );


    iframe.className =
      'agzz-youtube';



    /*
     * Privacy-enhanced YouTube player.
     */

    iframe.src =
      'https://www.youtube-nocookie.com/embed/' +
      encodeURIComponent(videoId) +
      '?autoplay=1' +
      '&playsinline=1' +
      '&rel=0' +
      '&modestbranding=1';



    iframe.title =
      'Aluglobus Zone Zero video';



    iframe.allow =
      'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';



    iframe.allowFullscreen =
      true;



    media.appendChild(
      iframe
    );


    activeCard =
      card;

  }



  /* =======================================================
     ONE CLICK LISTENER
     ======================================================= */

  grid.addEventListener(
    'click',
    function (event) {


      var trigger =
        event.target.closest(
          '.agzz-video-trigger'
        );


      if (!trigger) {
        return;
      }



      var card =
        trigger.closest(
          '[data-agzz-youtube]'
        );


      playVideo(
        card
      );

    }
  );

})();


/* Elementor V2 section 18 / a10a306 */
(function () {
  'use strict';


  /*
   * =========================================================
   * CLICK-TO-LOAD MP4
   * =========================================================
   *
   * Initial load:
   * - NO <video>
   * - NO MP4 request
   * - NO metadata request
   *
   * MP4 element is created only after user presses Play.
   */


  var videoBox =
    document.getElementById(
      'agprVideo'
    );


  if (videoBox) {


    var videoTrigger =
      videoBox.querySelector(
        '.agpr-play'
      );


    if (videoTrigger) {


      videoTrigger.addEventListener(
        'click',
        function () {


          if (
            videoBox.querySelector(
              '.agpr-video-player'
            )
          ) {

            return;

          }


          var src =
            videoBox.getAttribute(
              'data-video-src'
            );


          if (!src) {
            return;
          }


          var video =
            document.createElement(
              'video'
            );


          video.className =
            'agpr-video-player';


          video.controls =
            true;


          video.playsInline =
            true;


          video.preload =
            'metadata';


          video.src =
            src;


          videoBox.appendChild(
            video
          );


          var promise =
            video.play();


          if (
            promise &&
            typeof promise.catch ===
            'function'
          ) {

            promise.catch(
              function () {}
            );

          }

        },
        {
          once: true
        }
      );

    }

  }



  /*
   * =========================================================
   * GALLERY LIGHTBOX
   * =========================================================
   *
   * Created only after first image click.
   */


  var gallery =
    document.getElementById(
      'agprGallery'
    );


  if (!gallery) {
    return;
  }


  var dialog = null;

  var modalImage = null;

  var modalCaption = null;

  var lastFocus = null;



  function createLightbox() {

    if (dialog) {
      return;
    }


    dialog =
      document.createElement(
        'dialog'
      );


    dialog.className =
      'agpr-lightbox';


    dialog.setAttribute(
      'aria-label',
      'Expanded rebuild project image'
    );


    dialog.innerHTML =

      '<div class="agpr-lightbox-shell">' +

        '<button ' +
          'class="agpr-lightbox-close" ' +
          'type="button" ' +
          'aria-label="Close enlarged image">' +

          '<svg viewBox="0 0 24 24" aria-hidden="true">' +
            '<path d="M6 6l12 12"></path>' +
            '<path d="M18 6L6 18"></path>' +
          '</svg>' +

          '<span>Close</span>' +

        '</button>' +


        '<img ' +
          'class="agpr-lightbox-image" ' +
          'alt=""' +
        '>' +


        '<p class="agpr-lightbox-caption"></p>' +

      '</div>';


    document.body.appendChild(
      dialog
    );


    modalImage =
      dialog.querySelector(
        '.agpr-lightbox-image'
      );


    modalCaption =
      dialog.querySelector(
        '.agpr-lightbox-caption'
      );


    var close =
      dialog.querySelector(
        '.agpr-lightbox-close'
      );


    var shell =
      dialog.querySelector(
        '.agpr-lightbox-shell'
      );


    close.addEventListener(
      'click',
      closeLightbox
    );


    dialog.addEventListener(
      'click',
      function (event) {


        if (
          event.target === dialog ||
          event.target === shell
        ) {

          closeLightbox();

        }

      }
    );


    dialog.addEventListener(
      'close',
      cleanup
    );

  }



  function openLightbox(trigger) {

    createLightbox();


    lastFocus =
      document.activeElement;


    modalImage.src =
      trigger.getAttribute(
        'data-src'
      );


    modalImage.alt =
      trigger.querySelector(
        'img'
      )?.alt || '';


    modalCaption.textContent =
      trigger.getAttribute(
        'data-caption'
      ) || '';


    if (
      typeof dialog.showModal ===
      'function'
    ) {

      dialog.showModal();

    } else {

      dialog.setAttribute(
        'open',
        ''
      );

    }

  }



  function closeLightbox() {

    if (!dialog) {
      return;
    }


    if (
      typeof dialog.close ===
      'function'
    ) {

      dialog.close();

    } else {

      dialog.removeAttribute(
        'open'
      );

      cleanup();

    }

  }



  function cleanup() {

    if (modalImage) {

      modalImage.removeAttribute(
        'src'
      );

    }


    if (modalCaption) {

      modalCaption.textContent =
        '';

    }


    if (
      lastFocus &&
      typeof lastFocus.focus ===
      'function'
    ) {

      try {

        lastFocus.focus({
          preventScroll: true
        });

      } catch (error) {

        lastFocus.focus();

      }

    }

  }



  gallery.addEventListener(
    'click',
    function (event) {


      var trigger =
        event.target.closest(
          '[data-agpr-lightbox]'
        );


      if (!trigger) {
        return;
      }


      openLightbox(
        trigger
      );

    }
  );

})();
