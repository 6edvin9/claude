(function () {
  'use strict';

  function initGalleryLightbox() {
    if (!document.body.classList.contains('page-gallery')) return;

    var gallery = document.querySelector('#MainContent .multicolumn-list');
    if (!gallery) return;

    var dialog = null;
    var image = null;

    function ensureDialog() {
      if (dialog) return;

      dialog = document.createElement('dialog');
      dialog.className = 'ag-gallery-dialog';
      dialog.innerHTML = '<div class="ag-gallery-dialog__shell"><button class="ag-gallery-dialog__close" type="button" aria-label="Close image">×</button><img class="ag-gallery-dialog__image" alt=""></div>';
      document.body.appendChild(dialog);
      image = dialog.querySelector('.ag-gallery-dialog__image');

      dialog.querySelector('.ag-gallery-dialog__close').addEventListener('click', function () {
        dialog.close();
      });

      dialog.addEventListener('click', function (event) {
        if (event.target === dialog) dialog.close();
      });
    }

    gallery.addEventListener('click', function (event) {
      var clicked = event.target.closest('.multicolumn-card__image-wrapper img');
      if (!clicked) return;

      ensureDialog();
      image.src = clicked.currentSrc || clicked.src;
      image.alt = clicked.alt || 'Aluglobus project image';
      if (typeof dialog.showModal === 'function') {
        dialog.showModal();
      } else {
        dialog.setAttribute('open', '');
      }
    });
  }

  function initImportedProductDescription() {
    if (!document.body.classList.contains('template-product')) return;

    var root = document.querySelector('#MainContent .ag-product-description__content');
    if (!root || root.getAttribute('data-ag-import-normalized-v2') === 'true') return;
    root.setAttribute('data-ag-import-normalized-v2', 'true');

    var productHandle = (window.location.pathname.match(/\/products\/([^/?#]+)/) || [])[1] || '';
    root.setAttribute('data-ag-product-handle', productHandle);

    /*
      Catalog audit note:
      The live catalog contains a mix of intact Elementor widgets, partially
      flattened Elementor tabs/accordions, duplicated FAQ answers, duplicated
      instruction blocks, and image runs whose original WordPress row classes
      no longer survive in Shopify. These richer imported product pages get a
      slightly more aggressive image grouping threshold while simple profiles,
      caps, brackets, rails, etc. are left essentially untouched.
    */
    var richImportedProducts = {
      'classic-full-privacy-composite-fence': true,
      'alu60-slat-fence-panel-kit': true,
      'alu60-wall-topper': true,
      'alu-40-6-3-modern-horizontal-fence-kit-2': true,
      'alu-40-6-3-modern-horizontal-fence-kit-3': true,
      'alu-40-6-3-modern-horizontal-wall-topper-kit': true,
      'alu40-vertical-fence-kit-4-x-6': true,
      'alu40-vertical-fence-kit-5-x-6': true,
      'alu40-vertical-fence-kit-6-x-6': true,
      'alu20-horizontal-fence-kit-4-x-8': true,
      'alu20-horizontal-fence-kit-5-x-8': true,
      'alu20-horizontal-fence-kit-6-x-8': true,
      '6-3alu50-fence-panel-kit-4-x-6-3': true,
      '6-3alu50-fence-panel-kit-5-x-6-2': true,
      '6-3alu50-fence-panel-kit-6-x-6': true,
      '6-3alu40-fence-panel-kit-5-x-6': true,
      'h-d-alu40-6-3-woodgrain-slat-fence-panel-frame': true,
      'fence-alu40-6-3-woodgrain-slat-6-x-6-fence-panel-kit-1-2-gap-2way-post': true,
      'fence-florida-3way-post-alu40-6-x-6-fence-kit-1-2-gap-black': true,
      'alu15-horizontal-fence-kit-5-x-6': true,
      'alu15-horizontal-fence-kit-6-x-6': true,
      'alu15-horizontal-fence-kit-4-x-6': true,
      'alu-15-aluminum-f': true,
      'alu20-g': true,
      'alu-40-alu-15-combination-f': true,
      'alu-60-alu-20-combination-f': true,
      'alu-15-aluminum-g': true,
      'alu-40-alu-15-combination-g': true,
      'alu15-horizontal-sliding-gate-kit-12-x-6': true,
      'alu15-horizontal-sliding-gate-kit-18-x-6': true,
      'alu15-horizontal-gate-kits-4-x-6': true,
      'alu15-horizontal-gate-kits-6-x-6': true,
      'alu15-vertical-gate-kit-4x6': true,
      'alu60-tng-diy-gate-kit-6x6-2': true,
      '6-3alu50-horizontal-double-swing-gate-kit-12-x-6': true,
      'diy-pad-gate-universal-diy-4x6-door-plexiglass-system-only-no-plexiglass': true,
      'sliding-gate-laser-cut': true,
      'pedestrian-gate-laser-cut': true,
      'horizontal-modern-alu40-6-3-slat-sliding-gate-kit': true
    };

    function normalizeText(value) {
      return (value || '')
        .replace(/\u00a0/g, ' ')
        .replace(/[\t\r\n]+/g, ' ')
        .replace(/\s{2,}/g, ' ')
        .trim();
    }

    function directChildren(parent) {
      return Array.prototype.filter.call(parent && parent.children ? parent.children : [], function (child) {
        var tag = (child.tagName || '').toLowerCase();
        return tag !== 'script' && tag !== 'style' && tag !== 'template';
      });
    }

    function headingText(el) {
      return normalizeText(el && el.textContent).replace(/[:\-–—]+$/g, '').trim();
    }

    function isFaqHeading(el) {
      if (!el || !el.matches) return false;
      if (!el.matches('h1,h2,h3,h4,h5,h6,p,strong,div')) return false;
      var t = headingText(el);
      return /^(faq|faqs|frequently asked questions)$/i.test(t);
    }

    function isInstructionHeading(el) {
      if (!el || !el.matches) return false;
      if (!el.matches('h1,h2,h3,h4,h5,h6,p,strong,div')) return false;
      var t = headingText(el);
      return /^(instructions|installation instructions|install instructions)$/i.test(t);
    }

    function topLevelBlock(node) {
      if (!node) return null;
      var current = node;
      while (current.parentElement && current.parentElement !== root) current = current.parentElement;
      return current;
    }

    function elementIndex(el) {
      if (!el || !el.parentElement) return -1;
      return Array.prototype.indexOf.call(el.parentElement.children, el);
    }

    function uniqueStrings(values) {
      var seen = Object.create(null);
      return values.filter(function (value) {
        var key = normalizeText(value).toLowerCase();
        if (!key || seen[key]) return false;
        seen[key] = true;
        return true;
      });
    }

    function trimRepeatedTail(answer, priorAnswers) {
      var clean = normalizeText(answer);
      if (!clean) return '';

      /* Common WooCommerce import artifact: all answers are printed again
         after the final accordion item. Cut that repeated tail. */
      var earliest = -1;
      priorAnswers.forEach(function (previous) {
        var probe = normalizeText(previous);
        if (probe.length < 28) return;
        var needle = probe.slice(0, Math.min(90, probe.length));
        var idx = clean.indexOf(needle, 24);
        if (idx > 0 && (earliest < 0 || idx < earliest)) earliest = idx;
      });
      if (earliest > 0) clean = clean.slice(0, earliest).trim();

      /* Also catch exact repeated halves. */
      if (clean.length > 80) {
        var half = Math.floor(clean.length / 2);
        var a = normalizeText(clean.slice(0, half));
        var b = normalizeText(clean.slice(half));
        if (a && b && (a === b || a.indexOf(b) === 0 || b.indexOf(a) === 0)) clean = a.length <= b.length ? a : b;
      }
      return clean;
    }

    function parseFaqText(text) {
      var raw = normalizeText(text)
        .replace(/^FAQS?\s*/i, '')
        .replace(/^Frequently Asked Questions\s*/i, '');
      if (!raw || raw.indexOf('?') < 0) return [];

      /* Question marks are much more reliable than surviving WordPress markup.
         Work backwards from each ? to the previous sentence boundary. This
         correctly handles flattened imports such as "...time. Can I install?"
         without swallowing the preceding answer into the next question. */
      var questions = [];
      for (var pos = raw.indexOf('?'); pos >= 0; pos = raw.indexOf('?', pos + 1)) {
        var start = pos - 1;
        while (start >= 0 && '.!?'.indexOf(raw.charAt(start)) === -1) start -= 1;
        start += 1;
        var q = normalizeText(raw.slice(start, pos + 1))
          .replace(/^(faq|faqs|frequently asked questions)\s*/i, '')
          .replace(/^[•·\-–—:;\s]+/, '');
        if (q.length < 6 || q.length > 280) continue;
        questions.push({ question: q, start: start, end: pos + 1 });
      }
      if (!questions.length) return [];

      /* De-duplicate identical questions while preserving the first occurrence. */
      var uniqueQuestions = [];
      var qSeen = Object.create(null);
      questions.forEach(function (item) {
        var key = item.question.toLowerCase();
        if (qSeen[key]) return;
        qSeen[key] = true;
        uniqueQuestions.push(item);
      });

      var pairs = [];
      uniqueQuestions.forEach(function (item, index) {
        var nextStart = index + 1 < uniqueQuestions.length ? uniqueQuestions[index + 1].start : raw.length;
        var answer = normalizeText(raw.slice(item.end, nextStart))
          .replace(/^(answer\s*:?\s*)/i, '')
          .replace(/^[•·\-–—:;\s]+/, '');
        if (!answer) return;
        pairs.push({ question: item.question, answer: answer });
      });

      var deduped = [];
      pairs.forEach(function (pair) {
        pair.answer = trimRepeatedTail(pair.answer, deduped.map(function (p) { return p.answer; }));
        if (!pair.answer) return;
        deduped.push(pair);
      });
      return deduped.slice(0, 16);
    }

    function extractFaqPairsFromMarkup(scope) {
      var pairs = [];
      var seen = Object.create(null);

      var titleSelectors = [
        '.elementor-tab-title',
        '.elementor-accordion-title',
        '.elementor-toggle-title',
        'summary',
        '[class*="faq-question"]',
        '.schema-faq-question',
        '.rank-math-question',
        '[role="button"]',
        'button'
      ].join(',');

      var titles = scope.querySelectorAll ? scope.querySelectorAll(titleSelectors) : [];
      Array.prototype.forEach.call(titles, function (title) {
        var q = normalizeText(title.textContent);
        if (!q || q.length > 300 || q.indexOf('?') < 0) return;
        q = q.slice(0, q.indexOf('?') + 1);
        var key = q.toLowerCase();
        if (seen[key]) return;

        var answerNode = null;
        var controls = title.getAttribute && title.getAttribute('aria-controls');
        if (controls) answerNode = document.getElementById(controls);
        if (!answerNode && title.tagName && title.tagName.toLowerCase() === 'summary') {
          var details = title.parentElement;
          if (details) {
            var answerParts = Array.prototype.filter.call(details.children, function (child) { return child !== title; });
            var answerText = normalizeText(answerParts.map(function (child) { return child.textContent; }).join(' '));
            if (answerText) {
              seen[key] = true;
              pairs.push({ question: q, answer: answerText });
              return;
            }
          }
        }
        if (!answerNode) {
          var holder = title.closest && title.closest('.elementor-accordion-item, .elementor-toggle-item, [class*="faq-item"], details');
          if (holder) answerNode = holder.querySelector('.elementor-tab-content, [class*="faq-answer"], .schema-faq-answer, .rank-math-answer');
        }
        if (!answerNode) answerNode = title.nextElementSibling;
        var a = normalizeText(answerNode && answerNode.textContent);
        if (!a) return;
        seen[key] = true;
        pairs.push({ question: q, answer: a });
      });
      return pairs;
    }

    function buildSemanticFaq(heading, sourceBlocks, pairs) {
      var faq = document.createElement('section');
      faq.className = 'ag-semantic-faq';
      faq.setAttribute('aria-label', 'Frequently asked questions');

      var eyebrow = document.createElement('div');
      eyebrow.className = 'ag-semantic-faq__eyebrow';
      eyebrow.textContent = 'Product questions';

      var title = document.createElement('h2');
      title.className = 'ag-semantic-faq__title';
      title.textContent = 'Frequently Asked Questions';

      var list = document.createElement('div');
      list.className = 'ag-semantic-faq__list';

      pairs.forEach(function (pair, index) {
        var item = document.createElement('details');
        item.className = 'ag-semantic-faq__item';
        if (index === 0) item.open = false;

        var summary = document.createElement('summary');
        summary.className = 'ag-semantic-faq__question';
        summary.textContent = pair.question;

        var answer = document.createElement('div');
        answer.className = 'ag-semantic-faq__answer';
        var paragraph = document.createElement('p');
        paragraph.textContent = pair.answer;
        answer.appendChild(paragraph);

        item.appendChild(summary);
        item.appendChild(answer);
        list.appendChild(item);
      });

      faq.appendChild(eyebrow);
      faq.appendChild(title);
      faq.appendChild(list);

      var first = sourceBlocks[0] || topLevelBlock(heading) || heading;
      first.parentElement.insertBefore(faq, first);
      sourceBlocks.forEach(function (block) {
        block.classList.add('ag-import-source-hidden');
        block.setAttribute('aria-hidden', 'true');
      });
    }

    function normalizeFaqSections() {
      var all = Array.prototype.slice.call(root.querySelectorAll('h1,h2,h3,h4,h5,h6,p,strong,div'));
      var headings = all.filter(isFaqHeading).filter(function (el, index, arr) {
        return !arr.some(function (other) { return other !== el && other.contains && other.contains(el); });
      });

      headings.forEach(function (heading) {
        if (heading.closest('.ag-semantic-faq')) return;

        var sourceContainer = heading.closest('[class*="accordion"], [class*="toggle"], [class*="faq"]');
        var start = topLevelBlock(heading);
        var sourceBlocks = [];

        if (sourceContainer && root.contains(sourceContainer)) {
          sourceBlocks = [topLevelBlock(sourceContainer) || sourceContainer];
        } else if (start) {
          var block = start;
          while (block) {
            if (block !== start) {
              var boundaryHeading = block.querySelector && block.querySelector('h1,h2,h3');
              var boundaryText = boundaryHeading ? headingText(boundaryHeading) : '';
              if (boundaryText && !/^(faq|faqs)$/i.test(boundaryText) && /^(you may also like|related|recommended|all products)$/i.test(boundaryText)) break;
              if (boundaryHeading && /^H2$/i.test(boundaryHeading.tagName) && block.textContent.indexOf('?') < 0) break;
            }
            sourceBlocks.push(block);
            block = block.nextElementSibling;
          }
        }

        if (!sourceBlocks.length) sourceBlocks = [heading];
        var scopeText = sourceBlocks.map(function (b) { return b.textContent || ''; }).join(' ');
        var pairs = extractFaqPairsFromMarkup(sourceBlocks[0]);
        if (pairs.length < 2) pairs = parseFaqText(scopeText);
        if (!pairs.length) return;

        /* If the first top-level block contains substantial content before FAQ,
           hiding it would remove legitimate description copy. In that case hide
           only the FAQ heading and all following siblings within its local parent. */
        var startText = normalizeText(sourceBlocks[0].textContent);
        var headingAtStart = startText.toLowerCase().indexOf(headingText(heading).toLowerCase()) <= 40;
        if (!headingAtStart && heading.parentElement) {
          var local = [];
          var child = heading;
          while (child) {
            local.push(child);
            child = child.nextElementSibling;
          }
          if (local.length) sourceBlocks = local;
        }

        buildSemanticFaq(heading, sourceBlocks, pairs);
      });
    }

    function eligibleDescriptionImage(img) {
      if (!img || !img.getAttribute) return false;
      if (img.closest('.ag-semantic-gallery, .ag-semantic-faq')) return false;
      var src = img.currentSrc || img.getAttribute('src') || '';
      if (!src || /^data:image\/svg/i.test(src) || /\.svg(?:\?|$)/i.test(src)) return false;
      var cls = String(img.className || '');
      if (/icon|logo|avatar|emoji|payment/i.test(cls)) return false;
      var w = parseInt(img.getAttribute('width') || '0', 10);
      var h = parseInt(img.getAttribute('height') || '0', 10);
      if (w && h && Math.max(w, h) < 140) return false;
      return true;
    }

    function imageSourceUnit(img) {
      var current = img;
      var best = img;
      var depth = 0;
      while (current.parentElement && current.parentElement !== root && depth < 5) {
        var parent = current.parentElement;
        var imageCount = parent.querySelectorAll('img').length;
        var text = normalizeText(parent.textContent);
        var hasStructure = !!parent.querySelector('h1,h2,h3,h4,h5,h6,table,ul,ol,video,iframe,form');
        if (imageCount === 1 && text.length <= 180 && !hasStructure) best = parent;
        else break;
        current = parent;
        depth += 1;
      }
      return best;
    }

    function meaningfulCaption(img) {
      var unit = imageSourceUnit(img);
      var text = normalizeText(unit && unit.textContent);
      if (text && text.length >= 2 && text.length <= 90) return text;
      var alt = normalizeText(img.getAttribute('alt'));
      var productTitle = normalizeText(document.querySelector('.product__title h1') && document.querySelector('.product__title h1').textContent);
      if (alt && alt.length <= 90 && alt.toLowerCase() !== productTitle.toLowerCase() && !/\|\s*aluglobus/i.test(alt)) return alt;
      return '';
    }

    function cloneImageCard(img) {
      var card = document.createElement('figure');
      card.className = 'ag-semantic-gallery__item';
      var originalLink = img.closest('a');
      var clonedImage = img.cloneNode(true);
      clonedImage.removeAttribute('style');
      clonedImage.removeAttribute('width');
      clonedImage.removeAttribute('height');
      clonedImage.setAttribute('loading', 'lazy');
      clonedImage.setAttribute('decoding', 'async');

      if (originalLink && originalLink.contains(img) && normalizeText(originalLink.textContent).length < 10) {
        var link = document.createElement('a');
        link.href = originalLink.href;
        if (originalLink.target) link.target = originalLink.target;
        link.rel = originalLink.rel || 'noopener';
        link.appendChild(clonedImage);
        card.appendChild(link);
      } else {
        card.appendChild(clonedImage);
      }

      var captionText = meaningfulCaption(img);
      if (captionText) {
        var caption = document.createElement('figcaption');
        caption.textContent = captionText;
        card.appendChild(caption);
      }
      return card;
    }

    function normalizeImageGroups() {
      var ordered = Array.prototype.slice.call(root.querySelectorAll('h2,h3,h4,img'));
      var groups = [];
      var current = { heading: null, images: [] };
      groups.push(current);

      ordered.forEach(function (node) {
        if (node.tagName && /^H[234]$/.test(node.tagName)) {
          current = { heading: node, images: [] };
          groups.push(current);
        } else if (node.tagName === 'IMG' && eligibleDescriptionImage(node)) {
          current.images.push(node);
        }
      });

      groups.forEach(function (group) {
        var images = uniqueStrings(group.images.map(function (img) { return img.currentSrc || img.src || ''; }))
          .map(function (src) {
            return group.images.find(function (img) { return (img.currentSrc || img.src || '') === src; });
          })
          .filter(Boolean);
        if (images.length < 2) return;

        var heading = group.heading ? headingText(group.heading) : '';
        var mediaHeading = /(hardware|parts|portfolio|gallery|photos|examples|available colors|finishes|designs|applications|components|included)/i.test(heading);
        var aggressive = !!richImportedProducts[productHandle];
        var minimum = aggressive || mediaHeading ? 2 : 3;
        if (images.length < minimum) return;

        /* Avoid turning unrelated images spread throughout a long text-heavy
           section into one gallery unless this is a known rich import. */
        if (!aggressive && !mediaHeading && group.heading) {
          var block = topLevelBlock(group.heading);
          var textLength = normalizeText(block && block.textContent).length;
          if (textLength > 2600 && images.length < 4) return;
        }

        var gallery = document.createElement('div');
        gallery.className = 'ag-semantic-gallery';
        gallery.setAttribute('data-ag-count', String(images.length));
        if (images.length === 2) gallery.classList.add('ag-semantic-gallery--two');
        if (images.length >= 7) gallery.classList.add('ag-semantic-gallery--dense');

        images.forEach(function (img) {
          gallery.appendChild(cloneImageCard(img));
        });

        var firstUnit = imageSourceUnit(images[0]);
        firstUnit.parentElement.insertBefore(gallery, firstUnit);

        images.forEach(function (img) {
          var unit = imageSourceUnit(img);
          unit.classList.add('ag-import-source-hidden');
          unit.setAttribute('aria-hidden', 'true');
        });
      });
    }

    function dedupeImportedBlocks() {
      var parents = [root].concat(Array.prototype.slice.call(root.querySelectorAll('section,article,div')));
      parents.forEach(function (parent) {
        var children = directChildren(parent);
        var lastText = '';
        children.forEach(function (child) {
          if (child.classList.contains('ag-import-source-hidden')) return;
          var text = normalizeText(child.textContent);
          if (text.length >= 45 && text === lastText && !child.querySelector('img,video,iframe,table')) {
            child.classList.add('ag-import-source-hidden');
            child.setAttribute('aria-hidden', 'true');
            return;
          }
          if (text) lastText = text;
        });
      });
    }

    function normalizeLegacyAccordionMarkup() {
      var titles = root.querySelectorAll('.elementor-accordion .elementor-tab-title, .elementor-toggle .elementor-tab-title');
      Array.prototype.forEach.call(titles, function (title) {
        var content = title.nextElementSibling;
        var controls = title.getAttribute('aria-controls');
        if ((!content || !content.classList.contains('elementor-tab-content')) && controls) content = document.getElementById(controls);
        if (!content || !root.contains(content)) return;
        title.classList.add('ag-imported-faq-title');
        content.classList.add('ag-imported-faq-content');
      });

      var details = root.querySelectorAll('details.e-n-accordion-item, details[class*="accordion"], details[class*="faq"]');
      Array.prototype.forEach.call(details, function (item) { item.classList.add('ag-imported-details'); });
    }

    function killOversizedLegacyControls() {
      window.requestAnimationFrame(function () {
        var selectors = 'svg,i,[class*="icon"],[class*="plus"],[class*="minus"],[class*="expand"],[class*="collapse"]';
        var candidates = Array.prototype.slice.call(root.querySelectorAll(selectors));
        var oversized = [];
        /* Read geometry first, then mutate classes in a second pass. This avoids
           repeated forced style/layout recalculation inside the loop. */
        candidates.forEach(function (el) {
          if (el.closest('.ag-semantic-faq, .ag-semantic-gallery')) return;
          var cls = String(el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className || '');
          var text = normalizeText(el.textContent);
          var relevant = /accordion|toggle|faq|tab|icon|plus|minus|expand|collapse/i.test(cls) || /^[+−\-×]?$/.test(text);
          if (!relevant || text.length > 3) return;
          var rect = el.getBoundingClientRect();
          if (rect.width > 96 || rect.height > 96) oversized.push(el);
        });
        oversized.forEach(function (el) {
          el.classList.add('ag-import-oversized-control');
          el.setAttribute('aria-hidden', 'true');
        });
      });
    }

    /* Yield between normalization phases. Imported WooCommerce descriptions can
       contain hundreds of nodes; one monolithic cleanup task can become a long
       main-thread task and hurt INP if a shopper interacts at the same time. */
    var cleanupSteps = [
      normalizeLegacyAccordionMarkup,
      normalizeFaqSections,
      normalizeImageGroups,
      dedupeImportedBlocks,
      killOversizedLegacyControls
    ];
    var runCleanupStep = function (index) {
      if (index >= cleanupSteps.length) return;
      cleanupSteps[index]();
      var next = function () { runCleanupStep(index + 1); };
      if ('requestIdleCallback' in window) window.requestIdleCallback(next, { timeout: 600 });
      else window.setTimeout(next, 0);
    };
    runCleanupStep(0);
  }

  function init() {
    initGalleryLightbox();
    if (!document.body.classList.contains('template-product')) return;
    /* Imported-description cleanup is substantial DOM work. Run it when the
       browser is idle so it does not block the first paint or an early tap. */
    var runProductCleanup = function () { initImportedProductDescription(); };
    if ('requestIdleCallback' in window) {
      window.requestIdleCallback(runProductCleanup, { timeout: 1200 });
    } else {
      window.setTimeout(runProductCleanup, 80);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
